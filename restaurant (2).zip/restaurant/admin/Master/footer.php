</div></div>
<footer class="container">
<hr>
	<p>Website Developed and maintained by:</p>
    <p>PHP Developer</p>
</footer>
</body>
</html>