<section class="copyright">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 text-center">
        Copyright 2022 | Website Developed & Maintained By : <a href="#">PHP Developer</a> | 
        <a href="admin/adminlogin.php">Admin Login</a>
      </div>
    </div>
    <!-- / .row -->
  </div>
</section>
<a href="#top" class="topHome"><i class="fa fa-chevron-up fa-2x"></i></a>

<!--[if lte IE 8]><script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script><![endif]-->
<script src="js/modernizr-latest.js"></script>
<script src="js/jquery-1.8.2.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/jquery.isotope.min.js" type="text/javascript"></script>
<script src="js/fancybox/jquery.fancybox.pack.js" type="text/javascript"></script>
<script src="js/jquery.nav.js" type="text/javascript"></script>
<script src="js/maps.js" type="text/javascript"></script>
<script src="js/gmaps.js"></script>
<script src="js/jquery.fittext.js"></script>
<script src="js/waypoints.js"></script>
<script src="flexslider/jquery.flexslider.js"></script>
<!--<script src="contact/jqBootstrapValidation.js"></script>
 <script src="contact/contact_me.js"></script>-->
<script src="js/custom.js" type="text/javascript"></script>
<script src="js/owl-carousel/owl.carousel.js"></script>
</body>

</html>